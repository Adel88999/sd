﻿$(document).ready(function () {

    $("[type=file]").on("change", function () {
        // Name of file and placeholder
        var file = this.files[0].name;
        var dflt = $(this).attr("placeholder");
        if ($(this).val() != "") {
            $(this).next().children(".upload-file-name").text(file);
        } else {
            $(this).next().children(".upload-file-name").text(dflt);
        }
    });
});

